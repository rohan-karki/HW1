bbcp - This code is an implementation of bare-bones copy methodology to copy a file from source to destination

The code uses arrays and arguments to take the input, i.e. the souce file from the command line itself. Then it uses certain permission functions to set required permissions to the file. The code checks for mutiple test cases when it comes to copy function.

When the compiled binary was run against testcp.sh, the following test cases did not pass resulting in the output of errors:

Expected failure, but command returned 0:
  /home/ronnie/HW1/a.out file file2
Files '/etc/passwd' and 'file' differ.

Expected failure, but command returned 0:
  /home/ronnie/HW1/a.out file .
Files '/etc/passwd' and 'file' differ.
Files 'file1' and 'file2' differ.
./testcp.sh: 5/30 tests failed.

NOTE: The number of failed testcases change when the testcp.sh is run with root privileges.